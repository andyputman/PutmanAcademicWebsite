/*
    Matrix Classes (code) : part of CalcH1Symplectic

    Copyright 2009 Andrew Putman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include<vector>
#include<cstdlib>
#include<iostream>
#include "Matrix.h"

using namespace std;

void Matrix::FillRandomly(void)
{
	for (CounterType i=0;i<numRows;i++)
	{
		for (CounterType j=0;j<numCols;j++)
		{
			mat[i][j] = rand()%pk;
		}
	}
}

void Matrix::FillRandomly2(void)
{
	MatrixEntryType multiplier;
	for (CounterType i=0;i<numRows;i++)
	{
		multiplier = Pow(p,(rand()%k));
		for (CounterType j=0;j<numCols;j++)
		{
			mat[i][j] = ((rand()%pk) * multiplier) % pk;
		}
	}
}

void Matrix::PrintMatrix(void)
{
        for (CounterType i=0;i<numRows;i++)
        {
                cout << "|";
                for (CounterType j=0;j<numCols;j++)
                {
			// We add additional spaces if necessary so that everything lines up
                        if ((pk >= 10) && (mat[i][j] < 10))
                                cout << " ";
			if ((pk >= 100) && (mat[i][j] < 100))
				cout << " ";
                        cout << (unsigned int)mat[i][j];
                        if (j < numCols-1)
                                cout << " ";
                }
                cout << "|" << endl;
        }
}

void Matrix::FlipRows(CounterType row1, CounterType row2)
{
	CounterType i, temp;

	for (i=0;i<numCols;i++)
	{
		temp = mat[row2][i];
		mat[row2][i] = mat[row1][i];
		mat[row1][i] = temp;
	}
}

void Matrix::FlipCols(CounterType col1, CounterType col2)
{
	CounterType i, temp;

	for (i=0;i<numRows;i++)
	{
		temp = mat[i][col2];
		mat[i][col2] = mat[i][col1];
		mat[i][col1] = temp;
	}
}

void Matrix::AddToBottom(Matrix mat2)
{
	CounterType i,j;
	vector<MatrixEntryType> row(numCols,0);
	
	numRows = numRows + mat2.NumRows();
	for (i=0;i<mat2.NumRows();i++)
	{
		for (j=0;j<numCols;j++)
		{
			row[j] = mat2.Entry(i,j);
		}
		mat.push_back(row);
	}
}

void Matrix::AddToRight(Matrix mat2)
{
	CounterType i,j;
	
	numCols = numCols + mat2.NumCols();
	for (i=0;i<numRows;i++)
	{
		for (j=0;j<mat2.NumCols();j++)
		{
			mat[i].push_back(mat2.Entry(i,j));
		}
	}
}

vector<CounterType> Matrix::RowReduce(void)
{
	vector<CounterType> imageRanks(k+1,0);
	vector<MatrixEntryType> inv(pk,0);
	vector<CounterType> logs(pk,0);
	vector<MatrixEntryType> rowsUsed(numRows,0);
	vector<MatrixEntryType> colsUsed(numCols,0);
	CounterType workingCol, workingRow, foundNonzeroEntry, i,j, minVal, colFound, rowFound;

	// We first fill inv with the weak mult. inverses for the integers mod p^k.  For np^m with n not divisible by
	// p, the weak mult. inverse is the number x such that (np^m)x=p^m mod p^k.
	for (i=0; i<pk; i++)
	{
		inv[i] =  WeakInvert(i);
	}

	// We now fill up a table of logs mod p
	for (i=0,j=1; i<k; i++,j=j*p)
	{
		logs[j]=i;
	}

	// We iterate the following process until we can't find a nonzero entry to work with
	foundNonzeroEntry = 1;
	rowFound=0;
	colFound=0;
	workingRow=0;
	workingCol=0;
	while (foundNonzeroEntry==1)
	{
		foundNonzeroEntry = 0;
	
		// We go through the matrix, trying to find the nonzero entry whose p-valuation is minimal
		// REMARK : The vector rowsUsed/colsUsed contains a 0 if we haven't done anything with 
		// that row/col and a 1 if we have.
		// REMARK : We start with minVal=pk since p^k=0.  Also, we stop immediately if the valuation=1, as we
		// can't do any better.
		minVal = pk;
		for (workingCol=0;(workingCol<numCols) && (minVal != 1);workingCol++)
		{
			if (colsUsed[workingCol] == 0)
			{
				for (workingRow=0;(workingRow < numRows) && (minVal != 1);workingRow++)
				{
					if ((rowsUsed[workingRow] == 0) && (PValuation(mat[workingRow][workingCol]) < minVal))
					{
						minVal = PValuation(mat[workingRow][workingCol]);
						colFound = workingCol;
						rowFound = workingRow;
					}
				}
			}
		}

		if (minVal < pk)
		{
			// We found an entry to work on!
			foundNonzeroEntry = 1;
			colsUsed[colFound] = 1;
			rowsUsed[rowFound] = 1;
			imageRanks[k-logs[minVal]]++;

			// We multiply the row so that its leading term is of the form p^n for some n
			MultRow(rowFound, inv[mat[rowFound][colFound]]);

			// We add multiples of our row to each other row we haven't worked on to kill off the entry
			// in the current column.  We use (pk-1) instead of -1 because everything is unsigned.
			for (i=0;i<numRows;i++)
			{
				if ((rowsUsed[i] == 0) && (mat[i][colFound] != 0))
				{
					AddRow(rowFound, i, ((pk-1)*(mat[i][colFound] / minVal)) % pk);
				}
			}
		}
	}
	return(imageRanks);
}

vector<CounterType> Matrix::RowReduce2(void)
{
	vector<CounterType> imageRanks(k+1,0);
	vector<MatrixEntryType> inv(pk,0);
	vector<CounterType> logs(pk,0);
	CounterType rowsFilled = 0;
	CounterType colsFilled = 0;
	CounterType workingCol, workingRow, foundNonzeroEntry, i, j, minVal, colFound, rowFound;

	// We first fill inv with the weak mult. inverses for the integers mod p^k.  For np^m with n not divisible by
	// p, the weak mult. inverse is the number x such that (np^m)x=p^m mod p^k.
	for (i=0; i<pk; i++)
	{
		inv[i] =  WeakInvert(i);
	}

	// We now fill up a table of logs mod p
	for (i=0,j=1; i<k; i++,j=j*p)
	{
		logs[j]=i;
	}

	// We iterate the following process until we can't find a nonzero entry to work with
	foundNonzeroEntry = 1;
	rowFound=0;
	colFound=0;
	workingRow=0;
	workingCol=0;
	while (foundNonzeroEntry==1)
	{
		foundNonzeroEntry = 0;
	
		// We go through the matrix, trying to find the nonzero entry whose p-valuation is minimal
		// REMARK : We start with minVal=pk since p^k=0.  Also, we stop immediately if the valuation=1, as we
		// can't do any better.
		minVal = pk;
		for (workingCol=colsFilled;(workingCol<numCols) && (minVal != 1);workingCol++)
		{
			for (workingRow=rowsFilled;(workingRow < numRows) && (minVal != 1);workingRow++)
			{
				if (PValuation(mat[workingRow][workingCol]) < minVal)
				{
					minVal = PValuation(mat[workingRow][workingCol]);
					colFound = workingCol;
					rowFound = workingRow;
				}
			}
		}

		if (minVal < pk)
		{
			// We found an entry to work on!
			foundNonzeroEntry = 1;
			imageRanks[k-logs[minVal]]++;

                        FlipRows(rowFound,rowsFilled);
                        FlipCols(colFound,colsFilled);

			// We multiply the row so that its leading term is of the form p^n for some n
			MultRow(rowsFilled, inv[mat[rowsFilled][colsFilled]]);

			// We add multiples of our row to each other row we haven't worked on to kill off the entry
			// in the current column.  We use (pk-1) instead of -1 because everything is unsigned.
			for (i=0;i<numRows;i++)
			{
				if ((mat[i][colsFilled] != 0) && (i != rowsFilled))
				{
					AddRow(rowsFilled, i, ((pk-1)*(mat[i][colsFilled] / minVal)) % pk);
				}
			}
		
			rowsFilled++;
			colsFilled++;
		}
	}
	return(imageRanks);
}

vector<CounterType> Matrix::RowReduceVerbose(void)
{
	vector<CounterType> imageRanks(k+1,0);
	vector<MatrixEntryType> inv(pk,0);
	vector<CounterType> logs(pk,0);
	vector<MatrixEntryType> rowsUsed(numRows,0);
	vector<MatrixEntryType> colsUsed(numCols,0);
	CounterType workingCol, workingRow, foundNonzeroEntry, i,j, minVal, colFound, rowFound;

	// We first fill inv with the weak mult. inverses for the integers mod p^k.  For np^m with n not divisible by
	// p, the weak mult. inverse is the number x such that (np^m)x=p^m mod p^k.
	for (i=0; i<pk; i++)
	{
		inv[i] =  WeakInvert(i);
	}

	// We now fill up a table of logs mod p
	for (i=0,j=1; i<k; i++,j=j*p)
	{
		logs[j]=i;
	}

	// We iterate the following process until we can't find a nonzero entry to work with
	foundNonzeroEntry = 1;
	rowFound=0;
	colFound=0;
	workingRow=0;
	workingCol=0;
	cout << "Initial Matrix : " << endl;
	PrintMatrix();
	while (foundNonzeroEntry==1)
	{
		foundNonzeroEntry = 0;
	
		// We go through the matrix, trying to find the nonzero entry whose p-valuation is minimal
		// REMARK : The vector rowsUsed/colsUsed contains a 0 if we haven't done anything with 
		// that row/col and a 1 if we have.
		// REMARK : We start with minVal=pk since p^k=0.  Also, we stop immediately if the valuation=1, as we
		// can't do any better.
		minVal = pk;
		for (workingCol=0;(workingCol<numCols) && (minVal != 1);workingCol++)
		{
			if (colsUsed[workingCol] == 0)
			{
				for (workingRow=0;(workingRow < numRows) && (minVal != 1);workingRow++)
				{
					if ((rowsUsed[workingRow] == 0) && (PValuation(mat[workingRow][workingCol]) < minVal))
					{
						minVal = PValuation(mat[workingRow][workingCol]);
						colFound = workingCol;
						rowFound = workingRow;
					}
				}
			}
		}

		if (minVal < pk)
		{
			// We found an entry to work on!
			foundNonzeroEntry = 1;
			colsUsed[colFound] = 1;
			rowsUsed[rowFound] = 1;
			imageRanks[k-logs[minVal]]++;

			cout << "Multiply row " << rowFound << " to make entry " << colFound << " a power of p." << endl;
			// We multiply the row so that its leading term is of the form p^n for some n
			MultRow(rowFound, inv[mat[rowFound][colFound]]);
			PrintMatrix();

			// We add multiples of our row to each other row we haven't worked on to kill off the entry
			// in the current column.  We use (pk-1) instead of -1 because everything is unsigned.
			for (i=0;i<numRows;i++)
			{
				if ((rowsUsed[i] == 0) && (mat[i][colFound] != 0))
				{
					cout << "Add mutiple of row " << rowFound << " to row " << i << endl;
					AddRow(rowFound, i, ((pk-1)*(mat[i][colFound] / minVal)) % pk);
					PrintMatrix();
				}
			}
		}
	}
	return(imageRanks);
}

vector<CounterType> Matrix::RowReduceVerbose2(void)
{
	vector<CounterType> imageRanks(k+1,0);
	vector<MatrixEntryType> inv(pk,0);
	vector<CounterType> logs(pk,0);
	CounterType rowsFilled = 0;
	CounterType colsFilled = 0;
	CounterType workingCol, workingRow, foundNonzeroEntry, i, j, minVal, colFound, rowFound;

	// We first fill inv with the weak mult. inverses for the integers mod p^k.  For np^m with n not divisible by
	// p, the weak mult. inverse is the number x such that (np^m)x=p^m mod p^k.
	for (i=0; i<pk; i++)
	{
		inv[i] =  WeakInvert(i);
	}

	// We now fill up a table of logs mod p
	for (i=0,j=1; i<k; i++,j=j*p)
	{
		logs[j]=i;
	}

	// We iterate the following process until we can't find a nonzero entry to work with
	foundNonzeroEntry = 1;
	rowFound=0;
	colFound=0;
	workingRow=0;
	workingCol=0;
	cout << "Initial Matrix : " << endl;
	PrintMatrix();
	while (foundNonzeroEntry==1)
	{
		foundNonzeroEntry = 0;
	
		// We go through the matrix, trying to find the nonzero entry whose p-valuation is minimal
		// REMARK : We start with minVal=pk since p^k=0.  Also, we stop immediately if the valuation=1, as we
		// can't do any better.
		minVal = pk;
		for (workingCol=colsFilled;(workingCol<numCols) && (minVal != 1);workingCol++)
		{
			for (workingRow=rowsFilled;(workingRow < numRows) && (minVal != 1);workingRow++)
			{
				if (PValuation(mat[workingRow][workingCol]) < minVal)
				{
					minVal = PValuation(mat[workingRow][workingCol]);
					colFound = workingCol;
					rowFound = workingRow;
				}
			}
		}

		if (minVal < pk)
		{
			// We found an entry to work on!
			foundNonzeroEntry = 1;
			imageRanks[k-logs[minVal]]++;
			
			cout << "Flip row " << rowFound << " w/ row " << rowsFilled << " and col " << colFound << " w/ col " << colsFilled << endl;
                        FlipRows(rowFound,rowsFilled);
                        FlipCols(colFound,colsFilled);
			PrintMatrix();

			cout << "Multiply row " << rowsFilled << " to make entry " << colsFilled << " a power of p." << endl;			
			// We multiply the row so that its leading term is of the form p^n for some n
			MultRow(rowsFilled, inv[mat[rowsFilled][colsFilled]]);
			PrintMatrix();

			// We add multiples of our row to each other row we haven't worked on to kill off the entry
			// in the current column.  We use (pk-1) instead of -1 because everything is unsigned.
			for (i=0;i<numRows;i++)
			{
				if ((mat[i][colsFilled] != 0) && (i != rowsFilled))
				{
					cout << "Add mutiple of row " << rowsFilled << " to row " << i << endl;
					AddRow(rowsFilled, i, ((pk-1)*(mat[i][colsFilled] / minVal)) % pk);
					PrintMatrix();
				}
			}
		
			rowsFilled++;
			colsFilled++;
		}
	}
	return(imageRanks);
}

Matrix Matrix::operator+(Matrix mat2)
{
	Matrix ret(p, k, numRows, numCols);
	for (CounterType i=0;i<numRows;i++)
	{
		for (CounterType j=0;j<numCols;j++)
		{
			ret.Set(i,j, mat[i][j] + mat2.Entry(i,j));
		}
	}
	return(ret);
}

Matrix Matrix::operator-(Matrix mat2)
{
	Matrix ret(p, k, numRows, numCols);
	for (CounterType i=0;i<numRows;i++)
	{
		for (CounterType j=0;j<numCols;j++)
		{
			// Remark : We use (pk-1) instead of -1 because everthing is unsigned
			ret.Set(i,j, mat[i][j] + (pk-1)*mat2.Entry(i,j));
		}
	}
	return(ret);
}

Matrix Matrix::operator*(Matrix mat2)
{
	Matrix ret(p, k, numRows, mat2.NumCols());

	for (CounterType i=0;i<numRows;i++)
	{
		for (CounterType j=0;j<mat2.NumCols();j++)
		{
			MatrixEntryType ent = 0;
			for (CounterType k=0;k<numCols;k++)
			{
				ent = (ent + mat[i][k] * mat2.Entry(k,j)) % pk;
			}
			ret.Set(i,j,ent);
		}
	}
	return(ret);
}

bool Matrix::operator==(Matrix mat2)
{
	return(Compare(mat2));
}

bool Matrix::operator!=(Matrix mat2)
{
	return(!Compare(mat2));
}

MatrixEntryType Matrix::WeakInvert(MatrixEntryType x)
{
	MatrixEntryType weakUnit = PValuation(x) % pk;
	for (MatrixEntryType i=0; i<pk; i++)
	{
		if ((i*x)%pk == weakUnit)
			return(i);
	}
	return(0);
}

MatrixEntryType Matrix::PValuation(MatrixEntryType x)
{
	MatrixEntryType val=1;

	x = x % pk;
	if (x==0)
		return(pk);

	while ((x % p) == 0)
	{
		val = val * p;
		x = x / p;
	}

	return(val);
}


MatrixEntryType Matrix::Pow(MatrixEntryType x, MatrixEntryType y)
{
	MatrixEntryType ret = 1;

	for (CounterType i=0; i<y; i++)
	{
		ret = ret * x;
	}
	return(ret);
}

void Matrix::MultRow(CounterType row, MatrixEntryType mult)
{
	for (CounterType i=0;i<numCols;i++)
		mat[row][i] = (mat[row][i] * mult) % pk;
}

void Matrix::AddRow(CounterType row1, CounterType row2, MatrixEntryType mult)
{
        for (CounterType i=0;i<numCols;i++)
                mat[row2][i] = (mat[row1][i] * mult + mat[row2][i]) % pk;
}

bool Matrix::Compare(Matrix mat2)
{
	if ((p != mat2.P()) || (numRows != mat2.NumRows()) || (numCols != mat2.NumCols()))
		return(false);

	for (CounterType i=0;i<numRows;i++)
	{
		for (CounterType j=0;j<numCols;j++)
		{
			if (mat[i][j] != mat2.Entry(i,j))
				return(false);
		}
	}
	return(true);
}

Matrix Identity(CounterType p, CounterType k, CounterType n)
{
	Matrix ret(p, k, n, n);

	for (CounterType i=0;i<n;i++)
		ret.Set(i,i,1);

	return(ret);
}

Matrix Zero(CounterType p, CounterType k, CounterType numRows, CounterType numCols)
{
	Matrix ret(p, k, numRows, numCols);

	return(ret);
}

Matrix SubMatrix(Matrix mat, CounterType row1, CounterType col1, CounterType row2, CounterType col2)
{
	Matrix ret(mat.P(), mat.K(), row2-row1+1, col2-col1+1);

	for (CounterType i=row1;i<=row2;i++)
	{
		for (CounterType j=col1;j<=col2;j++)
		{
			ret.Set(i-row1, j-col1, mat.Entry(i,j));
		}
	}
	return(ret);
}

Matrix Inverse(Matrix mat)
{
	//We use the algorithm : adjoin the identity matrix to rhs, row reduce, then read inverse off from rhs.
	Matrix identityMatrix = Identity(mat.P(), mat.K(), mat.NumRows());
	mat.AddToRight(identityMatrix);
	mat.RowReduce2();
	return(SubMatrix(mat,0,mat.NumRows(),mat.NumRows()-1,2*mat.NumRows()-1));
}

Matrix Transpose(Matrix mat)
{
	Matrix ret(mat.P(), mat.K(), mat.NumCols(), mat.NumRows());

	for (CounterType i=0;i<mat.NumRows();i++)
	{
		for (CounterType j=0;j<mat.NumCols();j++)
		{
			ret.Set(j,i,mat.Entry(i,j));
		}
	}

	return(ret);
}

vector<CounterType> Image(Matrix mat)
{
	return(mat.RowReduce());
}

vector<CounterType> Kernel(Matrix mat)
{
	vector<CounterType> imageRanks = mat.RowReduce();
	vector<CounterType> kerRanks(mat.K()+1,0);

	kerRanks[mat.K()] = mat.NumCols() - imageRanks[mat.K()];
	for (CounterType i=1;i<mat.K();i++)
	{
		kerRanks[mat.K()] = kerRanks[mat.K()] - imageRanks[i];
		kerRanks[mat.K()-i] = imageRanks[i];
	}

	return(kerRanks);
}
