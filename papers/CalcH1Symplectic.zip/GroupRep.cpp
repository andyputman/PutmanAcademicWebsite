/*
    Group Representation Classes (code) : part of CalcH1Symplectic

    Copyright 2009 Andrew Putman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <vector>
#include <iostream>
#include <time.h>
#include "Matrix.h"
#include "Group.h"
#include "GroupRep.h"

GroupRep::GroupRep(Group grp_, CounterType p_, CounterType k_, CounterType dim_) : grp(grp_), p(p_), k(k_), dim(dim_), foundH0(0), foundH1(0)
{
	Matrix id = Identity(p,k,dim);
	pk = 1;
	for (CounterType i=0;i<k;i++)
		pk = pk * p;
	for (CounterType i=0;i<grp.NumGen();i++)
		action.push_back(id);
}

Matrix GroupRep::Action(Word wrd)
{
	CounterType i;
	Matrix mat = Identity(p,k,dim);
	for (i=0;i<wrd.Length();i++)
	{
		if (wrd.Sign(i) == 1)
			mat = mat * action[wrd.Letter(i)];
		else if (wrd.Sign(i) == -1)
			mat = mat * Inverse(action[wrd.Letter(i)]);
	}
	return(mat);
}

int GroupRep::TestRep(int verbose)
{
	CounterType i,j;
	Word rel;
	Matrix mat;
	time_t start, end;

	if (verbose>0) 
		cout << "Testing representation..." << endl;

	start = clock();

	for (i=0;i<grp.NumGen();i++)
	{
		mat = action[i];
		if ((mat.P() != p) || (mat.K() != k) || (mat.NumRows() != dim) || (mat.NumCols() != dim))
		{
			if (verbose>0)
				cout << "Error : Matrix associated to generator " << i << " is invalid." << endl;
			return(-1);
		}
	}

	for (i=0;i<grp.NumRel();i++)
	{
		rel = grp.Rel(i);
		Matrix mat = Identity(p,k,dim);
		for (j=0;j<rel.Length();j++)
		{
			if (rel.Sign(j) == 1)
				mat = mat * action[rel.Letter(j)];
			else if (rel.Sign(j) == -1)
				mat = mat * Inverse(action[rel.Letter(j)]);
			else{
				if (verbose>0)
					cout << "Error : Relation " << i << " invalid." << endl;
				return(-1);
			}
		}
		if (mat != Identity(p,k,dim))
		{
			if (verbose>0)
				cout << "Error : Relation " << i << " not satisfied." << endl;
			return(-1);
		}
	}
	end = clock();
	if (verbose>0)
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
	return(0);
}

Matrix GroupRep::InvariantsMatrix(void)
{
	Matrix mat(p, k, 0, dim);
	CounterType n;

	for (n=0;n<grp.NumGen();n++)
	{
		mat.AddToBottom(action[n] - Identity(p, k, dim));
	}
	return(mat);
}

void GroupRep::CalcH0(int testRep, int verbose)
{
	time_t start, end;
	CounterType n;

	foundH0 = 1;

	if ((testRep==1) && (TestRep(verbose) == -1))
		return;

	if (verbose>0)
		cout << endl << "Building matrix of whose kernel is the invariants..." << endl;
	start = clock();
	Matrix mat = InvariantsMatrix();
	end = clock();
	if (verbose>0)
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
	if (verbose>1)
	{
		cout << "Matrix whose kernel is the invariants is" << endl;
		mat.PrintMatrix();
	}

	if (verbose>0)
		cout << endl << "Calculating space of invariants..." << endl;
	start = clock();
	invariants = Kernel(mat);
	end = clock();
	if (verbose>0)
	{
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
		cout << "Space of invariants : " << endl;
		n=p;
	        for (unsigned int i=1;i<=k;i++)
	        {
			cout << "Number of Z/" << (unsigned int)n << "Z's : " << invariants[i] << endl;
			n=n*p;
	        }
	}
}

vector<CounterType> GroupRep::Invariants(void)
{
	if (foundH0 == 0)
		CalcH0(1,0);

	return(invariants);
}

Matrix GroupRep::StackHoriz(vector<Matrix> input)
{
	CounterType i;
	Matrix ret(input[0].P(), input[0].K(), input[0].NumRows(), 0);

	for (i=0;i<input.size();i++)
		ret.AddToRight(input[i]);

	return(ret);
}

vector<Matrix> GroupRep::DerivationRelation(CounterType n)
{
	CounterType i;
	Word rel = grp.Rel(n);
	vector<Matrix> ret;
	Matrix mat = Identity(p,k,dim);

	for (i=0;i<grp.NumGen();i++)
		ret.push_back(Matrix(p,k,dim,dim));

	for (i=0;i<rel.Length();i++)
	{
		if (rel.Sign(i) == 1)
		{
			ret[rel.Letter(i)] = ret[rel.Letter(i)] + mat;
			mat = mat * action[rel.Letter(i)];
		}
		else{
			ret[rel.Letter(i)] = ret[rel.Letter(i)] - mat * Inverse(action[rel.Letter(i)]);
			mat = mat * Inverse(action[rel.Letter(i)]);
		}
	}

	return(ret);
}

Matrix GroupRep::DerivationMatrix(void)
{
	Matrix mat(p, k, 0, dim * grp.NumGen());
	CounterType i;

	for (i=0;i<grp.NumRel();i++)
	{
		mat.AddToBottom(StackHoriz(DerivationRelation(i)));
	}
	return(mat);
}

/******************************************************************
 * PrincipleDerivationMatrix : Returns a matrix whose rows
 * correspond to principle derivations.
 *
 * We represent a principle derivation by a row with numGen*dim cols.  The first
 * dim cols of that row contain the transpose of the image of the first generator under the
 * principle derivation in question, the second dim cols the transpose of the image of the
 * second generator under the principle derivation, etc.
 *
 * The first row of the matrix corresponds to the principle derivation coming from (1,0,...,0),
 * the second to the principle derivation coming from (0,1,0,...,0), etc.
 *
 * The image of the returned matrix is the dimension of the space of principle derivations.
 ******************************************************************/

Matrix GroupRep::PrincipleDerivationMatrix(void)
{
	Matrix mat(p, k, 0, dim * grp.NumGen());
	CounterType i;

	for (i=0;i<dim;i++)
	{
		mat.AddToBottom(StackHoriz(PrincipleDerivationCreate(i)));
	}
	return(mat);
}

/******************************************************************
 * PrincipleDerivationCreate(n) : Returns the data for PrincipleDerivationMatrix
 * corresponding to the principle derivation coming from (0,...,0,1,0,...,0), where
 * the 1 is in the nth place.  The output is a vector of rows, one for each generator 
 * (containing the image of that generator under the principle derivation).
 ******************************************************************/

vector<Matrix> GroupRep::PrincipleDerivationCreate(CounterType n)
{
        CounterType i;
        vector<Matrix> ret;
        Matrix col(p, k, dim, 1);
        col.Set(n,0,1);

        for (i=0;i<grp.NumGen();i++)
        {
                ret.push_back(Transpose((action[i]) * col - col));
        }

        return(ret);
}

void GroupRep::CalcH1(int testRep, int verbose)
{
	time_t start, end;
	CounterType n;

	foundH1 = 1;

	if ((testRep==1) && (TestRep(verbose) == -1))
		return;

	if (verbose>0)
		cout << endl << "Building matrix of relations derivations must satisfy..." << endl;
	start = clock();
	Matrix mat = DerivationMatrix();
	end = clock();
	if (verbose>0)
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
	if (verbose>1)
	{
		cout << "Matrix of relations is" << endl;
		mat.PrintMatrix();
	}

	if (verbose>0)
		cout << endl << "Calculating space of derivations..." << endl;
	start = clock();
	derivations = Kernel(mat);
	end = clock();
	if (verbose>0)
	{
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
		cout << "Space of derivations : " << endl;
		n=p;
	        for (unsigned int i=1;i<=k;i++)
	        {
			cout << "Number of Z/" << (unsigned int)n << "Z's : " << derivations[i] << endl;
			n=n*p;
	        }
		cout << endl << "Building matrix whose rows are generators of principle derivations..." << endl;
	}
        start = clock();
        mat = PrincipleDerivationMatrix();
        end = clock();
        if (verbose>0)
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
	if (verbose>1)
	{
		cout << "Matrix whose rows are generators of principle derivations is" << endl;
		mat.PrintMatrix();
	}

        if (verbose>0)
		cout << endl << "Calculating dimension of space of principle derivations..." << endl;
        start = clock();
        principleDerivations = mat.RowReduce();
        end = clock();
        if (verbose>0)
	{
		cout << "Done!  It took " << ((float)end - (float)start) / CLOCKS_PER_SEC << " seconds." << endl;
		cout << "Space of principle derivations :" << endl;
                n=p;
		for (unsigned int i=1;i<=k;i++)
                {
                        cout << "Number of Z/" << (unsigned int)n << "Z's : " << principleDerivations[i] << endl;
			n=n*p;
                }
	}
}

vector<CounterType> GroupRep::Derivations(void)
{
	if (foundH1 == 0)
		CalcH1(1,0);

	return(derivations);
}

vector<CounterType> GroupRep::PrincipleDerivations(void)
{
	if (foundH1 == 0)
		CalcH1(1,0);

	return(principleDerivations);
}

GroupRep Dual(GroupRep rep)
{
	GroupRep ret(rep.Grp(), rep.P(), rep.K(), rep.Dim());

	for (CounterType n=0;n<ret.Grp().NumGen();n++)
	{
		ret.SetAction(n,Inverse(Transpose(rep.Action(n))));
	}

	return(ret);
}

GroupRep DirectSum(GroupRep rep1, GroupRep rep2)
{
        CounterType i,j,n;
        GroupRep ret(rep1.Grp(), rep1.P(), rep1.K(), rep1.Dim() + rep2.Dim());

        for (n=0;n<ret.Grp().NumGen();n++)
        {
                Matrix newAction = Zero(ret.P(), ret.K(), rep1.Dim() + rep2.Dim(), rep1.Dim() + rep2.Dim());
                for (i=0;i<rep1.Dim();i++)
                {
                        for (j=0;j<rep1.Dim();j++)
                        {
                                newAction.Set(i,j,rep1.Action(n).Entry(i,j));
                        }
                }
                for (i=0;i<rep2.Dim();i++)
                {
                        for (j=0;j<rep2.Dim();j++)
                        {
                                newAction.Set(i+rep1.Dim(), j + rep1.Dim(), rep2.Action(n).Entry(i,j));
                        }
                }
                ret.SetAction(n,newAction);
        }

        return(ret);
}

GroupRep Tensor(GroupRep rep1, GroupRep rep2)
{
	GroupRep ret(rep1.Grp(), rep1.P(), rep1.K(), rep1.Dim() * rep2.Dim());
	CounterType k1, k2;

	for (CounterType n=0;n<ret.Grp().NumGen();n++)
	{
		Matrix newAction = Zero(ret.P(), ret.K(), ret.Dim(), ret.Dim());

		for (CounterType i1=0;i1<rep1.Dim();i1++)
		{
			for (CounterType j1=0;j1<rep1.Dim();j1++)
			{
				k1=i1*rep2.Dim();
				for (CounterType i2=0;i2<rep2.Dim();i2++)
				{
					k2=j1*rep2.Dim();
					for (CounterType j2=0;j2<rep2.Dim();j2++)
					{
						newAction.Set(k1,k2,rep1.Action(n).Entry(i1,j1) * rep2.Action(n).Entry(i2,j2));
						k2++;
					}
					k1++;
				}
			}
		}
		ret.SetAction(n,newAction);
	}

	return(ret);
}

GroupRep TensorPower(GroupRep rep, CounterType k)
{
	GroupRep ret = rep;

	for (CounterType i=0;i<k-1;i++)
		ret = Tensor(ret,rep);
	
	return(ret);
}

