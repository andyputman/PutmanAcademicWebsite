/*
    Group and Word Classes (headers) : part of CalcH1Symplectic

    Copyright 2009 Andrew Putman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include<vector>
#include "Matrix.h"

#ifndef __GROUP

#define __GROUP

using namespace std;

/***************************************************************************
 * Group : Class containing a group
 *
 * CONSTRUCTOR : Takes the number of generators, returns a free group on that number of generators
 *
 * PUBLIC FCNS:
 * 	NumGen() : returns the number of generators
 * 	NumRel() : returns the number of relations
 *	Rel(i) : returns the ith relation
 *	AddRel(newRel) : Adds the relation newRel to the group
 *
 * OPERATIONS:
 * 	none
 *
 * FUNCTIONS THAT OPERATE ON / RETURN WORDS:
 * 	none
 *
 * PRIVATE FCNS:
 * 	none
 *
 * REMARKS:
 * 	1) It does minimal checking to make sure that it has valid inputs
 ***************************************************************************/

/***************************************************************************
 * Word : Class containing a word in the generators of a group
 *
 * CONSTRUCTOR : Takes no input, begins with the empty word
 *
 * PUBLIC FCNS:
 * 	Length() : Returns the length of the word
 * 	Letter(pos) : Returns the letter in position pos
 * 	Sign(pos) : Returns the sign of the letter in position pos
 * 	RightMult(gen,sign) : Multiplies the word on the right by the letter gen with sign sign
 *
 * OPERATIONS:
 * 	* : Multiplies two words
 *
 * FUNCTIONS THAT OPERATE ON / RETURN WORDS:
 * 	Inverse(toInvert) : Returns the group inverse of the word toInvert
 * 	Pow(input, exponent) : Returns input raised to the exponent power
 *	Gen(num) : Returns a word containing the single letter num with sign +1
 *
 * PRIVATE FCNS:
 * 	none
 *
 * REMARKS:
 * 	1) This is pretty skeletal right now; in particular, it does not have things to compare
 * 	words, etc.
 * 	2) It does minimal checking to make sure that it has valid inputs
 ***************************************************************************/

class Word{
	public:
	CounterType Length(void) { return(gens.size()); };
	CounterType Letter(CounterType pos) { return(gens[pos]); };
	int Sign(CounterType pos) { return(signs[pos]); };
	void RightMult(CounterType gen, CounterType sign);
	Word operator*(Word rhs);
	
	private:
	vector<CounterType> gens;
	vector<int> signs;
};

Word Inverse(Word toInvert);

Word Pow(Word input, int exponent);

Word Gen(CounterType num);

class Group{
	public:
	Group(CounterType numGen_=0) : numGen(numGen_), numRel(0) {};
	CounterType NumGen(void) { return(numGen); };
	CounterType NumRel(void) { return(numRel); };
	Word Rel(CounterType relNum) { return(relations[relNum]); };
	void AddRel(Word newRel) { numRel++; relations.push_back(newRel); };

	private:
	CounterType numGen, numRel;
	vector<Word> relations;
};

#endif
