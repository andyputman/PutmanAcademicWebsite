/*
    Group Representation Classes (headers) : part of CalcH1Symplectic

    Copyright 2009 Andrew Putman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include<vector>
#include "Matrix.h"
#include "Group.h"

#ifndef __GROUPREP

#define __GROUPREP

using namespace std;

/***************************************************************************
 * GroupRep : Class containing a group representation
 *
 * CONSTRUCTOR : Takes the group, the prime p and the number k such that the representation is over Z/(p^k Z), and the dimension of
 *               the representation.  Returns the trivial representation of that that dimension with that group and coefficients.
 *
 * PUBLIC FCNS:
 * 	Grp() : returns the group
 * 	P() : returns the prime p
 *	K() : returns the exponent k
 *	Dim() : returns the dimension of the representation
 *	Action(n) : returns the matrix giving the action of the nth generator of the group
 *	Action(word) : returns the matrix giving the action of the indicated word in the generators of the group
 *	SetAction(n,mat) : set the action of the nth generator to the matrix mat
 *	TestRep(verbose) : tests the representation to see if it is valid.  The variable verbose is 0 if you want
 *                         nothing printed and 1 if you want a description of what it is doing doing printed
 *	CalcH0(testrep,verbose) : Calculates the invariants of the representation.  Set testrep to 1 if you want the represenation
 *		                  tested first and 0 if you don't.  Set verbose to 0 if you want nothing printed, to 1 if you want
 *				  a description of what is doing printed, and to 2 if you want a description plus the relevant matrices
 *                                printed.
 *	Invariants() : returns a vector whose entries are the ranks of the pieces of the invariant subspace (the first entry is the
 *		       number of Z/p's, the second the number of Z/p^2, etc.)
 *	CalcH1(testrep,verbose) : Calculates H^1 of the representation.  Set testrep to 1 if you want the represenation
 *		                  tested first and 0 if you don't.  Set verbose to 0 if you want nothing printed, to 1 if you want
 *				  a description of what is doing printed, and to 2 if you want a description plus the relevant matrices
 *                                printed.
 *	Derivations() : returns a vector whose entries are the ranks of the pieces of the space of derivations (the first entry is the
 *                      number of Z/p's, the second the number of Z/p^2, etc.)
 *	PrincipleDerivations() : returns a vector whose entries are the ranks of the pieces of the space of principle derivations (the
 *			         the first entry is the number of Z/p's, the second the number of Z/p^2, etc.)
 *
 * OPERATIONS:
 * 	none
 *
 * FUNCTIONS THAT OPERATE ON / RETURN GroupReps:
 *	Dual(rep) : returns the dual of rep
 *	DirectSum(rep1, rep2) : returns the direct sum of rep1 and rep2
 *	Tensor(rep1, rep2) : returns the tensor product of rep1 and rep2
 *	TensorPower(rep, k) : returns the kth tensor power of rep
 *
 * PRIVATE FCNS:
 *	InvariantsMatrix() : creates a matrix whose kernel is the invariant vectors
 *	StackHoriz(input) : the input is a vector of matrices.  it returns the result of stacking these matrices horizontally.
 * 	DerivationRelation(n) , DerivationMatrix() : creates matrix whose kernel corresponds to the derivations.
 *	PrincipleDerivationCreate(n), PrincipleDerivationMatrix() : creates matrix whose image correspond to the principle derivations.
 *
 * REMARKS:
 * 	1) It does minimal checking to make sure that it has valid inputs
 ***************************************************************************/

class GroupRep{
	public:
	GroupRep(Group grp_, CounterType p_, CounterType k_, CounterType dim_);
	Group Grp(void) { return(grp); };
	CounterType P(void) { return(p); };
	CounterType K(void) { return(k); };
	CounterType Dim(void) { return(dim); };
	Matrix Action(CounterType n) { return(action[n]); };
	Matrix Action(Word wrd);
	void SetAction(CounterType n, Matrix mat) { action[n] = mat; };

	int TestRep(int verbose=0);

	void CalcH0(int testrep=1, int verbose=0);
	vector<CounterType> Invariants(void);
	void CalcH1(int testrep=1, int verbose=0);
	vector<CounterType> Derivations(void);
	vector<CounterType> PrincipleDerivations(void);

	private:
	Group grp;
	CounterType p, k, pk, dim;
	vector<Matrix> action;
	vector<CounterType> invariants, derivations, principleDerivations;
	CounterType foundH0, foundH1;

	Matrix InvariantsMatrix(void);
	Matrix StackHoriz(vector<Matrix> input);
	vector<Matrix> DerivationRelation(CounterType n);
	Matrix DerivationMatrix(void);
	vector<Matrix> PrincipleDerivationCreate(CounterType n);
	Matrix PrincipleDerivationMatrix(void);
};

GroupRep Dual(GroupRep rep);
GroupRep DirectSum(GroupRep rep1, GroupRep rep2);
GroupRep Tensor(GroupRep rep1, GroupRep rep2);
GroupRep TensorPower(GroupRep rep, CounterType k);
#endif
