/*
    Matrix Classes (headers) : part of CalcH1Symplectic

    Copyright 2009 Andrew Putman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include<vector>

#ifndef __MATRIX

#define __MATRIX

using namespace std;

/***************************************************************************
 * This is the data type for entries for our matrix.  On my machine, the unsigned
 * char is a single byte, so its maximum value is 255.  The most extreme thing that
 * any of the library functions does to an entry x before reducing mod p^k is x^2+x.  Thus
 * this data type is good as long as the prime p^k is at most 15 -- if you want
 * to use this library for larger primes, then increase the size of this data type
 ***************************************************************************/
typedef unsigned int MatrixEntryType;

/***************************************************************************
 * This is the data type for our counter (for instance, for rows/cols)
 ***************************************************************************/
typedef unsigned int CounterType;

/***************************************************************************
 * Matrix : Our matrix class over rings Z/p^k
 *
 * CONSTRUCTOR : Call w/ p, k, num of rows, and num of cols
 *
 * PUBLIC FCNS:
 *	P : returns the prime p
 *	K : returns the exponent k
 *	NumRows : returns the number of rows
 *	NumCols : returns the number of cols
 *
 *	Entry(row,col) : returns the entry at position (row,col)
 *	Set(row,col,val) : sets (row,col) to val
 *
 * 	FillRandomly : fills the matrix with random entries
 * 	FillRandomly2 : fills the matrix with random entries, but matrices have much less of a chance to be nonsingular
 * 	PrintMatrix : prints the matrix to the console
 *
 *	FlipRows(row1,row2) : Flips row1 and row2
 *	FlipCols(col1,col2) : Flips col1 and col2
 *	AddToBottom(mat) : adjoins the matrix mat to the bottom of the matrix
 *	AddToRight(mat) : adjoints the matrix mat to the right of the matrix
 *
 *	RowReduce : Performs Gaussian elimination (without reordering the rows) and returns a vector whose ith component
 *	            is the number of factors of Z/(p^i)Z in the image of the matrix (the 0th component is 0).
 *	RowReduceVerbose : Same as RowReduce but displays the intermediate steps
 *      RowReduce2 : Performs Gauss-Jordan elimination (reordering the rows, etc.) and returns a vector like RowReduce
 *      RowReduceVerbose2 : Same as RowReduce2 but displays the intermediate steps
 *
 * OPERATIONS:
 * 	+      : adds matrices
 * 	-      : subtracts matrices
 * 	*      : multiplies matrices
 * 	==, != : compares matrices
 *
 * FUNCTIONS THAT OPERATE ON / RETURN MATRICES:
 * 	Identity(p,k,n) : Returns an nxn identity matrix
 * 	Zero(p, k, numRows, numCols) : Returns an numRows x numCols zero matrix
 * 	Inverse(mat) : Returns inverse of mat (will produce nonsense matrix if inverse does not exist)
 * 	Transpose(mat) : Returns transpose of mat
 * 	SubMatrix(mat, row1, col1, row2, col2) : Returns submatrix of mat w/ corners (row1,col1) and (row2,col2)
 *	Rank(mat) : Returns the rank of mat
 *      Image(mat) : Returns a vector whose ith entry is the component of Z/(p^i)Z in the image of mat.  The 0th entry is 0.
 *      Kernel(mat) : Returns a vector whose ith entry is the component of Z/(p^i)Z in the kernel of mat.  The 0th entry is 0.
 *
 * PRIVATE FCNS:
 * 	PowP(x,y) : returns x to the power of y reduced mod p.  We need this during row reduction
 * 	Pow(x,y) : returns x to the power of y without reducing mod p
 * 	MultRow(row,mult) : multiply every entry of row by mult
 * 	AddRow(row1, row2, mult) : add mult times row1 to row2
 *	Compare(mat2) : compare mat to mat2 (used in == and !=)
 *
 * REMARKS:
 * 	1) Currently very little testing done to make sure things are valid input.  This should be fixed.
 * 	2) The code is written to be easy to read, not necessarily efficient
 ***************************************************************************/

class Matrix{
	public:
	Matrix(CounterType p_=1, CounterType k_=1, CounterType numRows_=0, CounterType numCols_=0) 
		: p((MatrixEntryType)p_), k((MatrixEntryType)k_), numRows(numRows_), numCols(numCols_), mat(numRows_,vector<MatrixEntryType>(numCols_, 0)){ pk = Pow(p,k); };

	CounterType P(void) { return(p); };
	CounterType K(void) { return(k); };
	CounterType NumRows(void) { return(numRows); };
	CounterType NumCols(void) { return(numCols); };

	MatrixEntryType Entry(CounterType row, CounterType col) { return(mat[row][col]); };
	void Set(CounterType row, CounterType col, MatrixEntryType val) { mat[row][col] = val % pk; };

	void FillRandomly(void);
        void FillRandomly2(void);
	void PrintMatrix(void);

	void FlipRows(CounterType row1, CounterType row2);
	void FlipCols(CounterType col1, CounterType col2);
	void AddToBottom(Matrix mat2);
	void AddToRight(Matrix mat2);

	vector<CounterType> RowReduce(void);
	vector<CounterType> RowReduceVerbose(void);
	vector<CounterType> RowReduce2(void);
	vector<CounterType> RowReduceVerbose2(void);

	Matrix operator+(Matrix mat2);
	Matrix operator-(Matrix mat2);
	Matrix operator*(Matrix mat2);
	bool operator==(Matrix mat2);
	bool operator!=(Matrix mat2);

	private:
	MatrixEntryType p,k,pk;
	CounterType numRows, numCols;
	vector<vector<MatrixEntryType> > mat;
	MatrixEntryType WeakInvert(MatrixEntryType x);
	MatrixEntryType PValuation(MatrixEntryType x);
	MatrixEntryType Pow(MatrixEntryType x, MatrixEntryType y);
	void MultRow(CounterType row, MatrixEntryType mult);
	void AddRow(CounterType row1, CounterType row2, MatrixEntryType mult);
	bool Compare(Matrix mat2);
};

Matrix Identity(CounterType p, CounterType k, CounterType n);
Matrix Zero(CounterType p, CounterType k, CounterType numRows, CounterType numCols);
Matrix SubMatrix(Matrix mat, CounterType row1, CounterType col1, CounterType row2, CounterType col2);
Matrix Inverse(Matrix mat);
Matrix Transpose(Matrix mat);
vector<CounterType> Image(Matrix mat);
vector<CounterType> Kernel(Matrix mat);

#endif
