/*
    SymplecticGroupClasses (code) : part of CalcH1Symplectic

    Copyright 2009 Andrew Putman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include<vector>
#include<iostream>
#include "Matrix.h"
#include "Group.h"
#include "GroupRep.h"

CounterType Exponentiate(CounterType x, CounterType y)
{
	CounterType ret=1;
	for (CounterType i=0;i<y;i++)
		ret = ret * x;
	return(ret);
}

/***********************************************************************
 * AddRelationsMod(*Mod,g,n) : Add the relations on the genus g mapping class group with n (=0 or 1) boundary
 * components.  This uses the standard Wajnryb presentation as found in Farb-Margalit's book "A Primer on Mapping
 * Class Groups".
 ***********************************************************************/
void AddRelationsMod(Group *Mod, CounterType g, CounterType n)
{
	Word a0=Gen(0), a1=Gen(1), a2=Gen(2), a3=Gen(3), a4=Gen(4), a5=Gen(5), a6=Gen(6);
	CounterType i,j;

	if (g==1)
	{
		Mod->AddRel(a0*a1*a0*Inverse(a1*a0*a1));
		if (n==0)
			Mod->AddRel(Pow(a0*a1,6));
		return;
	}

	//The 3-chain relation
	Word b0C = a4*a3*a2*a1*a1*a2*a3*a4;
	Word b0 = Inverse(b0C) * a0 * b0C;
	Mod->AddRel(Pow(a1*a2*a3,4) * Inverse(a0*b0));

	//The lantern relation
	if (g >= 3)
	{
		Word b1C = a4*a3*a5*a4;
		Word b1 = b1C * a0 * Inverse(b1C);
		Word b2C = a2*a1*a3*a2;
		Word b2 = b2C * b1 * Inverse(b2C);
		Word uC = a5*a6;
		Word u = uC * b1 * Inverse(uC);
		Word b3C = Inverse(a1*a2*a3*a4) * u * a2*a3*a4*a5*a6;
		Word b3 = Inverse(b3C) * a0 * b3C;
		Mod->AddRel(a0*b1*b2*Inverse(a1*a3*a5*b3));
	}

	//The hyperelliptic relation
	if (n == 0)
	{
		Word n1 = a1, n2 = b0;
		for (i=1;i<=g-2;i++)
		{
			Word w = Gen(2*i+4)*Gen(2*i+3)*Gen(2*i+2)*n2;
			w=w*(Gen(2*i+1)*Gen(2*i)*Gen(2*i+2)*Gen(2*i+1));
			w=w*(Gen(2*i+3)*Gen(2*i+2)*Gen(2*i+4)*Gen(2*i+3));
			w=w*(n2*Gen(2*i+2)*Gen(2*i+1)*Gen(2*i));
			Word n3 = w*n1*Inverse(w);
			n1=n2;
			n2=n3;
		}
		Word d = n2;
		Word h = Gen(1)*Gen(1);
		for (i=2;i<=2*g;i++)
			h = Gen(i)*h*Gen(i);
		Mod->AddRel(h*d*Inverse(d*h));
	}

	//The braid/commutation relations
	for (i=1;i<2*g;i++)
	{
		Word A=Gen(i), B=Gen(i+1);
		Mod->AddRel(A*B*A*Inverse(B*A*B));
		for (j=i+2;j<=2*g;j++)
		{
			Word C=Gen(j);
			Mod->AddRel(A*C*Inverse(C*A));
		}
	}
	for (i=1;i<=2*g;i++)
	{
		Word A=Gen(i);
		if (i==4)
			Mod->AddRel(a0*A*a0*Inverse(A*a0*A));
		else
			Mod->AddRel(a0*A*Inverse(A*a0));
	}
}

/***************************************************************************
 * AddRelationsSp(*Sp,g) : Add relations of Sp_{2g}(Z) to Sp.  We start with the mapping class group and then
 * add the (single) normal generator for the Torelli subgroup identified by Powell to get the symplectic group.
 ***************************************************************************/
void AddRelationsSp(Group *Sp, CounterType g)
{
	if (g==1)
	{
		AddRelationsMod(Sp,g,0);
	}
	else if (g==2)
	{
		AddRelationsMod(Sp,g,0);
		Sp->AddRel(Pow(Gen(1)*Gen(2),6));
	}
	else if (g>=3)
	{
		AddRelationsMod(Sp,g,1);
		Sp->AddRel(Pow(Gen(1)*Gen(2)*Gen(3),4)*Pow(Gen(0),-2));
	}
}

/***************************************************************************
 * AddRelationsSpL(*SpL, g, L) : Add relations of Sp_{2g}(Z/LZ) to SpL.  We start with the integral symplectic group
 * and then add the Lth power of the first generator, which by a theorem of Mennicke (in his paper on congruence subgroups
 * of the symplectic group) normally generates the level L congruence subgroup of the symplectic group.
 ***************************************************************************/
void AddRelationsSpL(Group *SpL, CounterType g, CounterType L)
{
	AddRelationsSp(SpL,g);

	SpL->AddRel(Pow(Gen(0),L));
}

/***************************************************************************
 * SetActionH(*ModH, g, p, k) : Sets the action of ModH to the standard action over Z/(p^k Z), where ModH is either
 * the mapping class group or the symplectic group.
 ***************************************************************************/
void SetActionH(GroupRep *ModH, CounterType g, CounterType p, CounterType k)
{
	CounterType i, pk;
	pk = Exponentiate(p,k);
	Matrix mat = Identity(p,k,2*g);

	if (g==1)
	{
		mat.Set(0,1,1);
		ModH->SetAction(0,mat);
		mat = Identity(p,k,2);
		mat.Set(1,0,pk-1);
		ModH->SetAction(1,mat);
		return;
	}

	// T_{a_0}
	mat.Set(1,g+1,1);
	ModH->SetAction(0,mat);

	// T_{a_1}
	mat = Identity(p,k,2*g);
	mat.Set(0,g,1);
	ModH->SetAction(1,mat);

	// T_{a_{2g}}
	mat = Identity(p,k,2*g);
	mat.Set(2*g-1,g-1,pk-1);
	ModH->SetAction(2*g,mat);

	for (i=1;i<g;i++)
	{
		// T_{a_{2i}}
		mat = Identity(p,k,2*g);
		mat.Set(g+i-1,i-1,pk-1);
		ModH->SetAction(2*i,mat);

		// T_{a_{2i+1}}
		mat = Identity(p,k,2*g);
		mat.Set(i-1,g+i-1,1);
		mat.Set(i,g+i-1,pk-1);
		mat.Set(i,g+i,1);
		mat.Set(i-1,g+i,pk-1);
		ModH->SetAction(2*i+1,mat);
	}
}

/***************************************************************************
 * AdjColToLie(p,k,g,col), AdjLieToCol(p,k,g,lie) : Goes back and forth between an element of the symplectic 
 * Lie algebra as a matrix and a column vector whose entries make up the entries of the matrix.
 ***************************************************************************/
Matrix AdjColToLie(CounterType p, CounterType k, CounterType g, Matrix col)
{
	Matrix ret(p, k, 2*g, 2*g);
	CounterType i,j,n,pk;
	pk = Exponentiate(p,k);

	n=0;
	for (i=0;i<g;i++)
	{
		for (j=0;j<g;j++)
		{
			ret.Set(i,j,col.Entry(n,0));
			ret.Set(g+j,g+i,(pk-1)*(col.Entry(n,0)));
			n++;
		}
	}
	for (i=0;i<g;i++)
	{
		for (j=i;j<g;j++)
		{
			ret.Set(g+i,j,col.Entry(n,0));
			ret.Set(g+j,i,col.Entry(n,0));
			n++;
			ret.Set(i,g+j,col.Entry(n,0));
			ret.Set(j,g+i,col.Entry(n,0));
			n++;
		}
	}

	return(ret);
}

Matrix AdjLieToCol(CounterType p, CounterType k, CounterType g, Matrix lie)
{
	Matrix ret(p,k,g*(2*g+1),1);
	CounterType i,j,n;

        n=0;
        for (i=0;i<g;i++)
        {
                for (j=0;j<g;j++)
                {
                        ret.Set(n,0,lie.Entry(i,j));
                        n++;
                }
        }
        for (i=0;i<g;i++)
        {
                for (j=i;j<g;j++)
                {
                        ret.Set(n,0,lie.Entry(g+i,j));
                        n++;
                        ret.Set(n,0,lie.Entry(i,g+j));
                        n++;
                }
        }

        return(ret);
}


/***************************************************************************
 * SetActionAdj(*ModAdj, g, p, k) : Sets the action of ModAdj to the adjoint action over Z/(p^k Z), where ModAdj is either
 * the mapping class group or the symplectic group.
 ***************************************************************************/
void SetActionAdj(GroupRep *ModAdj, CounterType g, CounterType p, CounterType k)
{
	GroupRep ModH = *ModAdj;
	CounterType i,j;

	SetActionH(&ModH,g,p,k);

	for (i=0;i<2*g+1;i++)
	{
		Matrix mat(p,k,g*(2*g+1),0);
		for (j=0;j<g*(2*g+1);j++)
		{
			Matrix col(p,k,g*(2*g+1),1);
			col.Set(j,0,1);
			Matrix spLie = AdjColToLie(p,k,g,col);
			spLie = ModH.Action(i) * spLie * Inverse(ModH.Action(i));
			col = AdjLieToCol(p,k,g,spLie);
			mat.AddToRight(col);
		}
		ModAdj->SetAction(i,mat);
	}
}

/*****************************************************************************
 * SymplecticH(g,L,p,k) : Returns Sp_{2g}(Z/LZ) with the standard rep over p^k.  Here p^k must divide L.
 *****************************************************************************/
GroupRep SymplecticH(CounterType g, CounterType L, CounterType p, CounterType k)
{
	CounterType numGen;

        if (g==1)
                numGen=2;
        else
                numGen=2*g+1;
							
	Group SpL(numGen);
	AddRelationsSpL(&SpL, g, L);

	GroupRep SpLH(SpL,p,k,2*g);
	SetActionH(&SpLH,g,p,k);
	return(SpLH);
}

/*****************************************************************************
 * SymplecticAdj(g,L,p,k) : Returns Sp_{2g}(Z/LZ) with the adjoint rep over p^k.  Here p^k must divide L.
 *****************************************************************************/
GroupRep SymplecticAdj(CounterType g, CounterType L, CounterType p, CounterType k)
{
	CounterType numGen;

	if (g==1)
		numGen=2;
	else
		numGen=2*g+1;

	Group SpL(numGen);
	AddRelationsSpL(&SpL, g, L);

	GroupRep SpLAdj(SpL,p,k,g*(2*g+1));
	SetActionAdj(&SpLAdj,g,p,k);
	return(SpLAdj);
}
												

